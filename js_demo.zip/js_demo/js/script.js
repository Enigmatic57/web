//alert('This is a test')

function askQuestion() {
    var p = prompt('Why this kolveri di?');
    if (p != null) {
        document.getElementById('question').innerHTML = p + "'u";
    }
}